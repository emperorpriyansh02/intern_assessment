package com.priyansh.intern_assessment.Controller;

import com.priyansh.intern_assessment.Model.PdfData;
import com.priyansh.intern_assessment.Service.PdfService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/pdf")
@AllArgsConstructor
@CrossOrigin(origins = "*")
public class PdfController {

    private final PdfService pdfService;

    @PostMapping("/upload")
    public ResponseEntity<PdfData> uploadPdf(@RequestParam("file") MultipartFile file) {
        PdfData extractedData = pdfService.parsePdf(file);
        return ResponseEntity.ok(extractedData);
    }

    @PostMapping("/secure")
    public ResponseEntity<String> generatePassword(
            @RequestParam String firstname,
            @RequestParam String dob,
            @RequestParam String accountType) {

        String password = pdfService.generatePassword(firstname, dob, accountType);
        return ResponseEntity.ok(password);
    }
}


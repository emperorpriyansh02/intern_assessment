package com.priyansh.intern_assessment.Service;

import com.priyansh.intern_assessment.Model.PdfData;
import org.springframework.web.multipart.MultipartFile;

public interface PdfService {
    PdfData parsePdf(MultipartFile file);
    String generatePassword(String firstname, String dob, String accountType);
}

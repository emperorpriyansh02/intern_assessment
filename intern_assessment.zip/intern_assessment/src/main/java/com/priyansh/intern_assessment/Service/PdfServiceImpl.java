package com.priyansh.intern_assessment.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.priyansh.intern_assessment.Model.PdfData;
import com.priyansh.intern_assessment.Service.PdfService;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.IOException;

@Service
public class PdfServiceImpl implements PdfService {

    private final WebClient webClient;

    @Value("${anthropic.api.url}")
    private String claudeApiUrl;

    @Value("${anthropic.api.key}")
    private String claudeApiKey;

    public PdfServiceImpl(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }

    @Override
    public PdfData parsePdf(MultipartFile file) {
        try {
            // Step 1: Extract text from PDF
            String pdfText = extractTextFromPdf(file);

            // Step 2: Send extracted text to Claude AI for structured response
            String response = getStructuredDataFromClaude(pdfText);

            // Step 3: Process response and extract details
            return parseClaudeResponse(response);

        } catch (Exception e) {
            e.printStackTrace();
            return new PdfData("Error processing PDF", "", "", "");
        }
    }

    @Override
    public String generatePassword(String firstname, String dob, String accountType) {
        return firstname.substring(0, 2).toUpperCase() + dob.replace("-", "") + accountType.length();
    }

    private String extractTextFromPdf(MultipartFile file) throws IOException {
        PDDocument document = PDDocument.load(file.getInputStream());
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(document);
        document.close();
        return text;
    }

    private String getStructuredDataFromClaude(String pdfText) {
        String prompt = "Extract the following details from this bank statement PDF:\n" +
                "Name, Email, Opening Balance, Closing Balance.\n\n" + pdfText;

        String response = webClient.post()
                .uri(claudeApiUrl)
                .header("Authorization", "Bearer " + claudeApiKey)
                .header("Content-Type", "application/json")
                .bodyValue("{ \"prompt\": \"" + prompt + "\" }")
                .retrieve()
                .bodyToMono(String.class)
                .block();

        return response;
    }

    private PdfData parseClaudeResponse(String response) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode rootNode = mapper.readTree(response);

            return new PdfData(
                    rootNode.path("name").asText(),
                    rootNode.path("email").asText(),
                    rootNode.path("opening_balance").asText(),
                    rootNode.path("closing_balance").asText()
            );

        } catch (Exception e) {
            return new PdfData("Error extracting data", "", "", "");
        }
    }
}


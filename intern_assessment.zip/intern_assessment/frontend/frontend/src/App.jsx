import { useState } from "react";
import axios from "axios";

export default function PdfUploader() {
  const [file, setFile] = useState(null);
  const [response, setResponse] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleUpload = async () => {
    if (!file) {
      setError("Please select a PDF file first.");
      return;
    }
    setError(null);
    setLoading(true);
    
    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await axios.post("http://localhost:9090/api/pdf/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setResponse(res.data);
    } catch (err) {
      setError("Error uploading file. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 max-w-md mx-auto bg-white rounded-xl shadow-md space-y-4">
      <h2 className="text-xl font-bold text-gray-700">PDF Uploader</h2>
      <input type="file" accept="application/pdf" onChange={handleFileChange} className="border p-2 rounded w-full" />
      <button 
        onClick={handleUpload} 
        disabled={loading}
        className="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-700 disabled:bg-gray-400">
        {loading ? "Uploading..." : "Upload PDF"}
      </button>
      {error && <p className="text-red-500">{error}</p>}
      {response && (
        <div className="mt-4 p-4 bg-gray-100 rounded">
          <h3 className="text-lg font-semibold">Extracted Data:</h3>
          <pre className="text-sm text-gray-700">{JSON.stringify(response, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}


